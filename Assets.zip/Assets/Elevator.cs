using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Elevator : MonoBehaviour
{
    public int currentFloor = 0;
    public float speed = 2f;

    private Queue<int> requests = new Queue<int>();
    private bool isMoving = false;

    void Update()
    {
        if (!isMoving && requests.Count > 0)
        {
            StartCoroutine(MoveToFloor(requests.Dequeue()));
        }
    }

    public void AddRequest(int floor)
    {
        if (!requests.Contains(floor))
            requests.Enqueue(floor);
    }

    IEnumerator MoveToFloor(int targetFloor)
    {
        isMoving = true;

        float targetY = targetFloor * 3f;

        while (Mathf.Abs(transform.position.y - targetY) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(
                transform.position,
                new Vector3(transform.position.x, targetY, 0),
                speed * Time.deltaTime
            );

            yield return null;
        }

        currentFloor = targetFloor;
        isMoving = false;
    }
}
