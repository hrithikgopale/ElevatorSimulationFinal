using UnityEngine;

public class ElevatorManager : MonoBehaviour
{
    public Elevator[] elevators;

    public void RequestElevator(int floor)
    {
        Elevator best = elevators[0];
        int minDistance = Mathf.Abs(best.currentFloor - floor);

        foreach (var e in elevators)
        {
            int dist = Mathf.Abs(e.currentFloor - floor);
            if (dist < minDistance)
            {
                minDistance = dist;
                best = e;
            }
        }

        best.AddRequest(floor);
    }
}
